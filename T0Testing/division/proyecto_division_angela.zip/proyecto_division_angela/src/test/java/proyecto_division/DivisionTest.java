/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package proyecto_division;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.function.Executable;

/**
 *
 * @author angsaegim
 */
public class DivisionTest {
    
    public DivisionTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of calcularDivision method, of class Division.
     */
    @Test
    public void testCalcularDivision1() throws Exception {
        System.out.println("calcularDivision correcta");
        float dividendo = 12F;
        float divisor = 2F;
        Division instance = new Division();
        float expResult = 6F;
        float result = instance.calcularDivision(dividendo, divisor);
        assertEquals(expResult, result, 0);
    }
    
    @Test
    public void testCalcularDivision2() throws Exception {
        System.out.println("calcularDivision con divisor 0 (exception)");
        float dividendo = 0.0F;
        float divisor = 0.0F;
        Division instance = new Division();
        assertThrows(Exception.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                float result = instance.calcularDivision(dividendo, divisor);
            }
        });
    }
    
}
