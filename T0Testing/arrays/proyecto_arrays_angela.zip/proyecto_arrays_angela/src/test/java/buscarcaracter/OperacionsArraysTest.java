/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package buscarcaracter;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author angsaegim
 */
public class OperacionsArraysTest {
    
    public OperacionsArraysTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of busca method, of class OperacionsArrays.
     */
    @Test
    public void testBusca1() {
        System.out.println("busca caracter en el arreglo (que está)");
        char c = 'K';
        char[] v = {'A','A','A','K','A','A','A'};
        OperacionsArrays instance = new OperacionsArrays();
        boolean expResult = true;
        boolean result = instance.busca(c, v);
        assertEquals(expResult, result);
    }
    
    @Test
    public void testBusca2() {
        System.out.println("busca caracter (menor) en el arreglo (que no está)");
        char c = 'A';
        char[] v = {'K','K','K'};
        OperacionsArrays instance = new OperacionsArrays();
        boolean expResult = false;
        boolean result = instance.busca(c, v);
        assertEquals(expResult, result);
    }
    
    @Test
    public void testBusca3() {
        System.out.println("busca en array vacío");
        char c = 'K';
        char[] v = {};
        OperacionsArrays instance = new OperacionsArrays();
        boolean expResult = false;
        boolean result = instance.busca(c, v);
        assertEquals(expResult, result);
    }
    
    @Test
    public void testBusca4() {
        System.out.println("busca (caracter MAYOR)- que no esta;");
        char c = 'J';
        char[] v = {'C', 'D', 'E', 'F', 'G'};
        OperacionsArrays instance = new OperacionsArrays();
        boolean expResult = false;
        boolean result = instance.busca(c, v);
        assertEquals(expResult, result);
    }
    
}
