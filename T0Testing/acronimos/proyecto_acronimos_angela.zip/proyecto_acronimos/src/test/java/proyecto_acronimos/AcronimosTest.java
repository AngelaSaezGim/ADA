/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package proyecto_acronimos;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author angsaegim
 */
public class AcronimosTest {
    
    public AcronimosTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of obtenerAcronimo method, of class Acronimos.
     */
    @Test
    
    //1 CADENA VACIA
    public void testObtenerAcronimo1() {
        System.out.println("obtener Acronimo cadena vacia");
        String cadena ="";
        Acronimos instance = new Acronimos();
        String expResult ="";
        String result = instance.obtenerAcronimo(cadena);
        assertEquals(expResult, result);
    }
    
    @Test
    //2 CADENA LLENA - CON SOLO ESPACIOS
    public void testObtenerAcronimo2() {
        System.out.println("obtenerAcronimo con solo espacios");
        String cadena ="    ";
        Acronimos instance = new Acronimos();
        String expResult ="";
        String result = instance.obtenerAcronimo(cadena);
        assertEquals(expResult, result);
    }
    
     @Test
    //3 CADENA LLENA - ALGUN CARACTER que no es solo espacio if (i==0){
    public void testObtenerAcronimo3() {
        System.out.println("obtenerAcronimo con un caracter");
        String cadena = "hola";
        Acronimos instance = new Acronimos();
        String expResult = "h.";
        String result = instance.obtenerAcronimo(cadena);
        assertEquals(expResult, result);
    }
     @Test
    //4 CADENA LLENA - CON CARACTERES - RELLENO + ESPACIOS 
    public void testObtenerAcronimo4() {
        System.out.println("obtenerAcronimo con un caracter y espacios");
        String cadena = "hola     mundo";
        Acronimos instance = new Acronimos();
        String expResult = "h.m.";
        String result = instance.obtenerAcronimo(cadena);
        assertEquals(expResult, result);
    }
     //CODE COVERAGE - SHOW REPORT
    
}
