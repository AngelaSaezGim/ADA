/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package proyecto_factorial;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.function.Executable;

/**
 *
 * @author angsaegim
 */
public class FactorialTest {

    public FactorialTest() {
    }

    @BeforeAll
    public static void setUpClass() {
    }

    @AfterAll
    public static void tearDownClass() {
    }

    @BeforeEach
    public void setUp() {
    }

    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of factorial method, of class Factorial.
     */
    @Test
    public void testFactorial() throws Exception {
        System.out.println("factorial que da excepcion (número menor a 0)");
        byte n = -1;
        Factorial instance = new Factorial();
        assertThrows(Exception.class, new Executable() {

            @Override

            public void execute() throws Throwable {

                float result = instance.factorial(n);

            }
        });
    }

    @Test
    public void testFactorial2() throws Exception {
        System.out.println("factorial mayor a 0 que n=1 ");
        byte n = 1;
        Factorial instance = new Factorial();
        float expResult = 1F;
        float result = instance.factorial(n);
        assertEquals(expResult, result, 0);
    }
    
    @Test
    public void testFactorial3() throws Exception {
        System.out.println("factorial mayor a 0 que n es mayor a 2 (for)");
        byte n = 4;
        Factorial instance = new Factorial();
        float expResult = 24F;
        float result = instance.factorial(n);
        assertEquals(expResult, result, 0);
    }
    
}
